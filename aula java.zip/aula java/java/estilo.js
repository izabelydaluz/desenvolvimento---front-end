function slide1(){
    document.getElementById('imagem').src="img/e.jpeg" ;
    setTimeout("slide2()", 3000)
    
    }
    
function slide2(){
    document.getElementById('imagem').src="img/c.jpg";
    setTimeout("slide3()", 3000)
    
    }
    
function slide3(){
    document.getElementById('imagem').src="img/w.avif";
    setTimeout("slide1()", 3000)
    
    }

// --------- 1 ---------
const pagina1= document.body.id;

if (pagina1 === 'pagina-home') {
const imagem1 = document.getElementById('img1');

if (imagem1) {
  imagem1.addEventListener('mouseenter', function () {
    imagem1.style.transform = 'scale(1.2)'; 
    imagem1.src = 'img/um2.webp';

    const minhaDiv = document.getElementById('borda1');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto1');
    if (textoElemento) {
      textoElemento.textContent = "Perfume Giorgio Armani: 500R$";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento5 = document.querySelector('.texto5');
    if (textoElemento5) {
      textoElemento5.textContent = "quantidade: 100Ml";
      textoElemento5.style.marginTop = "40px";
    }
  });

  imagem1.addEventListener('mouseleave', function () {
    imagem1.style.transform = 'scale(1)'; 
    imagem1.src = 'img/um.jpg';

    const minhaDiv = document.getElementById('borda1');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto1');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento5 = document.querySelector('.texto5');
    if (textoElemento5) {
      textoElemento5.textContent = "";
      textoElemento5.style.marginTop = "40px";
    }
  });
}


// --------- 2 ---------
const imagem2 = document.getElementById('img2');

if (imagem2) {
  imagem2.addEventListener('mouseenter', function () {
    imagem2.style.transform = 'scale(1.2)'; 
    imagem2.src = 'img/dois2.webp';

    const Div = document.getElementById('borda2');
    if (Div) {
      Div.style.transform = 'scale(1.2)';
      Div.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto2');
    if (textoElemento) {
      textoElemento.textContent = "Lily Eau de Parfum: 250R$";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento6 = document.querySelector('.texto6');
    if (textoElemento6) {
      textoElemento6.textContent = "quantidade: 75Ml";
      textoElemento6.style.marginTop = "40px";
    }
  });

  imagem2.addEventListener('mouseleave', function () {
    imagem2.style.transform = 'scale(1)'; 
    imagem2.src = 'img/dois.webp';

    const Div = document.getElementById('borda2');
    if (Div) {
      Div.style.transform = 'scale(1)';
      Div.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto2');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento6 = document.querySelector('.texto6');
    if (textoElemento6) {
      textoElemento6.textContent = "";
      textoElemento6.style.marginTop = "40px";
    }
  });
}


// --------- 3 ---------
const imagem3 = document.getElementById('img3');

if (imagem3) {
  imagem3.addEventListener('mouseenter', function () {
    imagem3.style.transform = 'scale(1.2)'; 
    imagem3.src = 'img/tres2.webp';

    const Div = document.getElementById('borda3');
    if (Div) {
      Div.style.transform = 'scale(1.2)';
      Div.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto3');
    if (textoElemento) {
      textoElemento.textContent = "Essencial Deo Parfum: 300R$";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento7 = document.querySelector('.texto7');
    if (textoElemento7) {
      textoElemento7.textContent = "quantidade: 100Ml";
      textoElemento7.style.marginTop = "40px";
    }
  });

  imagem3.addEventListener('mouseleave', function () {
    imagem3.style.transform = 'scale(1)'; 
    imagem3.src = 'img/tres.jpg';

    const Div = document.getElementById('borda3');
    if (Div) {
      Div.style.transform = 'scale(1)';
      Div.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto3');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento7 = document.querySelector('.texto7');
    if (textoElemento7) {
      textoElemento7.textContent = "";
      textoElemento7.style.marginTop = "40px";
    }
  });
}


// --------- 4 ---------
const imagem4 = document.getElementById('img4');

if (imagem4) {
  imagem4.addEventListener('mouseenter', function () {
    imagem4.style.transform = 'scale(1.2)'; 
    imagem4.src = 'img/quatro2.webp';

    const Div = document.getElementById('borda4');
    if (Div) {
      Div.style.transform = 'scale(1.2)';
      Div.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto4');
    if (textoElemento) {
      textoElemento.textContent = "Eudora Kids: 29,99R$";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento8 = document.querySelector('.texto8');
    if (textoElemento8) {
      textoElemento8.textContent = "quantidade: 100Ml";
      textoElemento8.style.marginTop = "40px";
    }
  });

  imagem4.addEventListener('mouseleave', function () {
    imagem4.style.transform = 'scale(1)'; 
    imagem4.src = 'img/quatro.webp';

    const Div = document.getElementById('borda4');
    if (Div) {
      Div.style.transform = 'scale(1)';
      Div.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto4');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento8 = document.querySelector('.texto8');
    if (textoElemento8) {
      textoElemento8.textContent = "";
      textoElemento8.style.marginTop = "40px";
    }
  });
}
}

// -----------------------------------------------------catalogo
 

function slide(){
document.getElementById('img1').src="img/f.webp";
setTimeout("slide_d()", 3000)

}

function slide_d(){
document.getElementById('img1').src="img/f2.jpg";
setTimeout("slide_t()", 3000)

}

function slide_t(){
document.getElementById('img1').src="img/f3.webp";
setTimeout("slide4()", 3000)


}

function slide4(){
document.getElementById('img1').src="img/m.jpg";
setTimeout("slide5()", 3000)

}

function slide5(){
document.getElementById('img1').src="img/m2.webp";
setTimeout("slide6()", 3000)

}

function slide6(){
document.getElementById('img1').src="img/m3.jpg";
setTimeout("slide7()", 3000)


}
function slide7(){
document.getElementById('img1').src="img/k.png";
setTimeout("slide8()", 3000)

}

function slide8(){
document.getElementById('img1').src="img/k2.webp";
setTimeout("slide()", 3000)

}

// --------------------------------------------------------contato
function s1(){
    document.getElementById('L').src="img/F5.webp" ;
    setTimeout("s2()", 3000)
    
    }
    
function s2(){
    document.getElementById('L').src="img/m4.webp";
    setTimeout("s3()", 3000)
    
    }
    
function s3(){
    document.getElementById('L').src="img/K2.png";
    setTimeout("s1()", 3000)
    
    }
  
function w1(){
    document.getElementById('S').src="img/M5.webp" ;
    setTimeout("w2()", 3000)
    
    }
    
function w2(){
    document.getElementById('S').src="img/K3.jpg";
    setTimeout("w3()", 3000)
    
    }
    
function w3(){
    document.getElementById('S').src="img/F4.webp";
    setTimeout("w1()", 3000)
    
    }

function a1(){
    document.getElementById('A').src="img/K4.webp" ;
    setTimeout("a2()", 3000)
    
    }
    
function a2(){
    document.getElementById('A').src="img/M1.jpg";
    setTimeout("a3()", 3000)
    
    }
    
function a3(){
    document.getElementById('A').src="img/F2.avif";
    setTimeout("a1()", 3000)
    
    }
function l1(){
    document.getElementById('W').src="img/M3.png" ;
    setTimeout("l2()", 3000)
    
    }
    
function l2(){
    document.getElementById('W').src="img/K1.jpg";
    setTimeout("l3()", 3000)
    
    }
    
function l3(){
    document.getElementById('W').src="img/F5.webp";
    setTimeout("l1()", 3000)
    
    }
// ------------------------------------------------------------2
function u1(){
    document.getElementById('U').src="img/u.webp" ;
    setTimeout("u2()", 3000)
    
    }
    
function u2(){
    document.getElementById('U').src="img/u2.jpg";
    setTimeout("u3()", 3000)
    
    }
    
function u3(){
    document.getElementById('U').src="img/u3.webp";
    setTimeout("u1()", 3000)
    
    }
  
function v1(){
    document.getElementById('V').src="img/v.jpg" ;
    setTimeout("v2()", 3000)
    
    }
    
function v2(){
    document.getElementById('V').src="img/v2.jpg";
    setTimeout("v3()", 3000)
    
    }
    
function v3(){
    document.getElementById('V').src="img/v3.webp";
    setTimeout("v1()", 3000)
    
    }

function i1(){
    document.getElementById('I').src="img/i.png" ;
    setTimeout("i2()", 3000)
    
    }
    
function i2(){
    document.getElementById('I').src="img/i2.jpg";
    setTimeout("i3()", 3000)
    
    }
    
function i3(){
    document.getElementById('I').src="img/i3.jpg";
    setTimeout("i1()", 3000)
    
    }
function o1(){
    document.getElementById('O').src="img/o.jpg" ;
    setTimeout("o2()", 3000)
    
    }
    
function o2(){
    document.getElementById('O').src="img/o2.jpg";
    setTimeout("o3()", 3000)
    
    }
    
function o3(){
    document.getElementById('O').src="img/o3.jpg";
    setTimeout("o1()", 3000)
    
    }
// ------------------------------------maquiagem

if (pagina1=== 'pagina-maquiagem') {

const imagem5 = document.getElementById('img5');

if (imagem5) {
  imagem5.addEventListener('mouseenter', function () {
    imagem5.style.transform = 'scale(1.2)'; 
    imagem5.src = 'img/ma2.webp';

    const minhaDiv = document.getElementById('borda5');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto9');
    if (textoElemento) {
      textoElemento.textContent = "Pó Iluminador";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento13 = document.querySelector('.texto13');
    if (textoElemento13) {
      textoElemento13.textContent = "preço: 49,99R$";
      textoElemento13.style.marginTop = "40px";
    }
  });

  imagem5.addEventListener('mouseleave', function () {
    imagem5.style.transform = 'scale(1)'; 
    imagem5.src = 'img/ma1.webp';

    const minhaDiv = document.getElementById('borda5');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto9');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento13 = document.querySelector('.texto13');
    if (textoElemento13) {
      textoElemento13.textContent = "";
      textoElemento13.style.marginTop = "40px";
    }
  });
}

const imagem6 = document.getElementById('img6');

if (imagem6) {
  imagem6.addEventListener('mouseenter', function () {
    imagem6.style.transform = 'scale(1.2)'; 
    imagem6.src = 'img/ma4.jpg';

    const minhaDiv = document.getElementById('borda6');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto10');
    if (textoElemento) {
      textoElemento.textContent = "Stick Pele Multifuncional";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento14 = document.querySelector('.texto14');
    if (textoElemento14) {
      textoElemento14.textContent = "preço: 89,99R$";
      textoElemento14.style.marginTop = "40px";
    }
  });

  imagem6.addEventListener('mouseleave', function () {
    imagem6.style.transform = 'scale(1)'; 
    imagem6.src = 'img/ma3.webp';

    const minhaDiv = document.getElementById('borda6');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto10');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento14 = document.querySelector('.texto14');
    if (textoElemento14) {
      textoElemento14.textContent = "";
      textoElemento14.style.marginTop = "40px";
    }
  });
}
const imagem7 = document.getElementById('img7');

if (imagem7) {
  imagem7.addEventListener('mouseenter', function () {
    imagem7.style.transform = 'scale(1.2)'; 
    imagem7.src = 'img/ma6.webp';

    const minhaDiv = document.getElementById('borda7');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto11');
    if (textoElemento) {
      textoElemento.textContent = "Hidra Lábios ";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento15 = document.querySelector('.texto15');
    if (textoElemento15) {
      textoElemento15.textContent = "preço: 39,99R$";
      textoElemento15.style.marginTop = "40px";
    }
  });

  imagem7.addEventListener('mouseleave', function () {
    imagem7.style.transform = 'scale(1)'; 
    imagem7.src = 'img/ma5.jpg';

    const minhaDiv = document.getElementById('borda7');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto11');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento15= document.querySelector('.texto15');
    if (textoElemento15) {
      textoElemento15.textContent = "";
      textoElemento15.style.marginTop = "40px";
    }
  });
}

const imagem8 = document.getElementById('img8');

if (imagem8) {
  imagem8.addEventListener('mouseenter', function () {
    imagem8.style.transform = 'scale(1.2)'; 
    imagem8.src = 'img/ma7.png';

    const minhaDiv = document.getElementById('borda8');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto12');
    if (textoElemento) {
      textoElemento.textContent = "Pó Solto Soft Silk";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento16 = document.querySelector('.texto16');
    if (textoElemento16) {
      textoElemento16.textContent = "preço: 59,99R$";
      textoElemento16.style.marginTop = "40px";
    }
  });

  imagem8.addEventListener('mouseleave', function () {
    imagem8.style.transform = 'scale(1)'; 
    imagem8.src = 'img/ma8.webp';

    const minhaDiv = document.getElementById('borda8');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto12');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento16= document.querySelector('.texto16');
    if (textoElemento16) {
      textoElemento16.textContent = "";
      textoElemento16.style.marginTop = "40px";
    }
  });
}
const imagem9 = document.getElementById('img9');

if (imagem9) {
  imagem9.addEventListener('mouseenter', function () {
    imagem9.style.transform = 'scale(1.2)'; 
    imagem9.src = 'img/ma10.webp';

    const minhaDiv = document.getElementById('borda9');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto17');
    if (textoElemento) {
      textoElemento.textContent = "Base e Corretivo Matte ";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento21 = document.querySelector('.texto21');
    if (textoElemento21) {
      textoElemento21.textContent = "preço: 59,90R$";
      textoElemento21.style.marginTop = "40px";
    }
  });

  imagem9.addEventListener('mouseleave', function () {
    imagem9.style.transform = 'scale(1)'; 
    imagem9.src = 'img/ma9.webp';

    const minhaDiv = document.getElementById('borda9');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto17');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento21 = document.querySelector('.texto21');
    if (textoElemento21) {
      textoElemento21.textContent = "";
      textoElemento21.style.marginTop = "40px";
    }
  });
}

const imagem10 = document.getElementById('img10');

if (imagem10) {
  imagem10.addEventListener('mouseenter', function () {
    imagem10.style.transform = 'scale(1.2)'; 
    imagem10.src = 'img/ma12.jpg';

    const minhaDiv = document.getElementById('borda10');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto18');
    if (textoElemento) {
      textoElemento.textContent = "Batons Sticks Ginger Glow";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento22 = document.querySelector('.texto22');
    if (textoElemento22) {
      textoElemento22.textContent = "preço: 59,20R$";
      textoElemento22.style.marginTop = "40px";
    }
  });

  imagem10.addEventListener('mouseleave', function () {
    imagem10.style.transform = 'scale(1)'; 
    imagem10.src = 'img/ma11.webp';

    const minhaDiv = document.getElementById('borda10');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto18');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento22 = document.querySelector('.texto22');
    if (textoElemento22) {
      textoElemento22.textContent = "";
      textoElemento22.style.marginTop = "40px";
    }
  });
}
const imagem11 = document.getElementById('img11');

if (imagem11) {
  imagem11.addEventListener('mouseenter', function () {
    imagem11.style.transform = 'scale(1.2)'; 
    imagem11.src = 'img/ma14.webp';

    const minhaDiv = document.getElementById('borda11');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto19');
    if (textoElemento) {
      textoElemento.textContent = "Batom Liquido Creamy Matte";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento23 = document.querySelector('.texto23');
    if (textoElemento23) {
      textoElemento23.textContent = "preço: 69,20R$";
      textoElemento23.style.marginTop = "40px";
    }
  });

  imagem11.addEventListener('mouseleave', function () {
    imagem11.style.transform = 'scale(1)'; 
    imagem11.src = 'img/ma13.JPG';

    const minhaDiv = document.getElementById('borda11');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto19');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento23= document.querySelector('.texto23');
    if (textoElemento23) {
      textoElemento23.textContent = "";
      textoElemento23.style.marginTop = "40px";
    }
  });
}

const imagem12 = document.getElementById('img12');

if (imagem12) {
  imagem12.addEventListener('mouseenter', function () {
    imagem12.style.transform = 'scale(1.2)'; 
    imagem12.src = 'img/ma16.webp';

    const minhaDiv = document.getElementById('borda12');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto20');
    if (textoElemento) {
      textoElemento.textContent = "Paleta de Sombras Ginger Glow";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento24 = document.querySelector('.texto24');
    if (textoElemento24) {
      textoElemento24.textContent = "preço: 79,90R$";
      textoElemento24.style.marginTop = "40px";
    }
  });

  imagem12.addEventListener('mouseleave', function () {
    imagem12.style.transform = 'scale(1)'; 
    imagem12.src = 'img/ma15.jpg';

    const minhaDiv = document.getElementById('borda12');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto20');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento24= document.querySelector('.texto24');
    if (textoElemento24) {
      textoElemento24.textContent = "";
      textoElemento24.style.marginTop = "40px";
    }
  });
}
}
// ---------------------------------perfume

if (pagina1=== 'pagina-perfume'){
const imagem13 = document.getElementById('img13');

if (imagem13) {
  imagem13.addEventListener('mouseenter', function () {
    imagem13.style.transform = 'scale(1.2)'; 
    imagem13.src = 'img/pe1.webp';

    const minhaDiv = document.getElementById('borda13');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto25');
    if (textoElemento) {
      textoElemento.textContent = "Hugo Boss Bottled";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento35 = document.querySelector('.texto35');
    if (textoElemento35) {
      textoElemento35.textContent = "preço: 342,00R$";
      textoElemento35.style.marginTop = "40px";
    }
  });

  imagem13.addEventListener('mouseleave', function () {
    imagem13.style.transform = 'scale(1)'; 
    imagem13.src = 'img/pe.webp';

    const minhaDiv = document.getElementById('borda13');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto25');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento35 = document.querySelector('.texto35');
    if (textoElemento35) {
      textoElemento35.textContent = "";
      textoElemento35.style.marginTop = "40px";
    }
  });
}

const imagem14 = document.getElementById('img14');

if (imagem14) {
  imagem14.addEventListener('mouseenter', function () {
    imagem14.style.transform = 'scale(1.2)'; 
    imagem14.src = 'img/per3.webp';

    const minhaDiv = document.getElementById('borda14');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto26');
    if (textoElemento) {
      textoElemento.textContent = "Perfume Granado Expedição 75ml";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento36 = document.querySelector('.texto36');
    if (textoElemento36) {
      textoElemento36.textContent = "preço:  325,00R$";
      textoElemento36.style.marginTop = "40px";
    }
  });

  imagem14.addEventListener('mouseleave', function () {
    imagem14.style.transform = 'scale(1)'; 
    imagem14.src = 'img/per2.webp';

    const minhaDiv = document.getElementById('borda14');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto26');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento36 = document.querySelector('.texto36');
    if (textoElemento36) {
      textoElemento36.textContent = "";
      textoElemento36.style.marginTop = "40px";
    }
  });
}
const imagem15 = document.getElementById('img15');

if (imagem15) {
  imagem15.addEventListener('mouseenter', function () {
    imagem15.style.transform = 'scale(1.2)'; 
    imagem15.src = 'img/per5.jpg';

    const minhaDiv = document.getElementById('borda15');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto27');
    if (textoElemento) {
      textoElemento.textContent = "Perfume Attracione Men";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento36 = document.querySelector('.texto37');
    if (textoElemento36) {
      textoElemento36.textContent = "preço: 143,90R$";
      textoElemento36.style.marginTop = "40px";
    }
  });

  imagem15.addEventListener('mouseleave', function () {
    imagem15.style.transform = 'scale(1)'; 
    imagem15.src = 'img/per4.jpg';

    const minhaDiv = document.getElementById('borda15');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto27');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento36= document.querySelector('.texto37');
    if (textoElemento36) {
      textoElemento36.textContent = "";
      textoElemento36.style.marginTop = "40px";
    }
  });
}

const imagem16 = document.getElementById('img16');

if (imagem16) {
  imagem16.addEventListener('mouseenter', function () {
    imagem16.style.transform = 'scale(1.2)'; 
    imagem16.src = 'img/per8.webp';

    const minhaDiv = document.getElementById('borda16');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto28');
    if (textoElemento) {
      textoElemento.textContent = "Eudora Impression 100ml";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento38 = document.querySelector('.texto38');
    if (textoElemento38) {
      textoElemento38.textContent = "preço: 165,00R$";
      textoElemento38.style.marginTop = "40px";
    }
  });

  imagem16.addEventListener('mouseleave', function () {
    imagem16.style.transform = 'scale(1)'; 
    imagem16.src = 'img/per7.webp';

    const minhaDiv = document.getElementById('borda16');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto28');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento38= document.querySelector('.texto38');
    if (textoElemento38) {
      textoElemento38.textContent = "";
      textoElemento38.style.marginTop = "40px";
    }
  });
}
const imagem17 = document.getElementById('img17');

if (imagem17) {
  imagem17.addEventListener('mouseenter', function () {
    imagem17.style.transform = 'scale(1.2)'; 
    imagem17.src = 'img/per10.jpg';

    const minhaDiv = document.getElementById('borda17');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto29');
    if (textoElemento) {
      textoElemento.textContent = "Chloé";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento39 = document.querySelector('.texto39');
    if (textoElemento39) {
      textoElemento39.textContent = "preço: 651,04R$";
      textoElemento39.style.marginTop = "40px";
    }
  });

  imagem17.addEventListener('mouseleave', function () {
    imagem17.style.transform = 'scale(1)'; 
    imagem17.src = 'img/per9.png';

    const minhaDiv = document.getElementById('borda17');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto29');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento39 = document.querySelector('.texto39');
    if (textoElemento39) {
      textoElemento39.textContent = "";
      textoElemento39.style.marginTop = "40px";
    }
  });
}

const imagem18 = document.getElementById('img18');

if (imagem18) {
  imagem18.addEventListener('mouseenter', function () {
    imagem18.style.transform = 'scale(1.2)'; 
    imagem18.src = 'img/per12.jpg';

    const minhaDiv = document.getElementById('borda18');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto30');
    if (textoElemento) {
      textoElemento.textContent = "Chanel Coco ";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento40 = document.querySelector('.texto40');
    if (textoElemento40) {
      textoElemento40.textContent = "preço: 327,98R$";
      textoElemento40.style.marginTop = "40px";
    }
  });

  imagem18.addEventListener('mouseleave', function () {
    imagem18.style.transform = 'scale(1)'; 
    imagem18.src = 'img/per11.webp';

    const minhaDiv = document.getElementById('borda18');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto30');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento40 = document.querySelector('.texto40');
    if (textoElemento40) {
      textoElemento40.textContent = "";
      textoElemento40.style.marginTop = "40px";
    }
  });
}
const imagem19 = document.getElementById('img19');

if (imagem19) {
  imagem19.addEventListener('mouseenter', function () {
    imagem19.style.transform = 'scale(1.2)'; 
    imagem19.src = 'img/per14.jpg';

    const minhaDiv = document.getElementById('borda19');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto31');
    if (textoElemento) {
      textoElemento.textContent = "Perfume Lattafa Asad 100 Ml";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento41 = document.querySelector('.texto41');
    if (textoElemento41) {
      textoElemento41.textContent = "preço: 146,00R$";
      textoElemento41.style.marginTop = "40px";
    }
  });

  imagem19.addEventListener('mouseleave', function () {
    imagem19.style.transform = 'scale(1)'; 
    imagem19.src = 'img/per13.jpg';

    const minhaDiv = document.getElementById('borda19');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto31');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento41= document.querySelector('.texto41');
    if (textoElemento41) {
      textoElemento41.textContent = "";
      textoElemento41.style.marginTop = "40px";
    }
  });
}

const imagem20 = document.getElementById('img20');

if (imagem20) {
  imagem20.addEventListener('mouseenter', function () {
    imagem20.style.transform = 'scale(1.2)'; 
    imagem20.src = 'img/per17.jpg';

    const minhaDiv = document.getElementById('borda20');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto32');
    if (textoElemento) {
      textoElemento.textContent = "Golden Gardênia 75ml";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento42 = document.querySelector('.texto42');
    if (textoElemento42) {
      textoElemento42.textContent = "preço: 229,90R$";
      textoElemento42.style.marginTop = "40px";
    }
  });

  imagem20.addEventListener('mouseleave', function () {
    imagem20.style.transform = 'scale(1)'; 
    imagem20.src = 'img/per16.jpg';

    const minhaDiv = document.getElementById('borda20');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto32');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento42= document.querySelector('.texto42');
    if (textoElemento42) {
      textoElemento42.textContent = "";
      textoElemento42.style.marginTop = "40px";
    }
  });
}
    
}
// ------------------------------------------rosto
if (pagina1=== 'pagina-rosto'){
const imagem21 = document.getElementById('img21');

if (imagem21) {
  imagem21.addEventListener('mouseenter', function () {
    imagem21.style.transform = 'scale(1.2)'; 
    imagem21.src = 'img/r2.webp';

    const minhaDiv = document.getElementById('borda21');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto43');
    if (textoElemento) {
      textoElemento.textContent = "Cerave Loção Hidratante 473ml";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento53 = document.querySelector('.texto53');
    if (textoElemento53) {
      textoElemento53.textContent = "preço: 99,99R$";
      textoElemento53.style.marginTop = "40px";
    }
  });

  imagem21.addEventListener('mouseleave', function () {
    imagem21.style.transform = 'scale(1)'; 
    imagem21.src = 'img/r1.jpg';

    const minhaDiv = document.getElementById('borda21');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto43');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento53 = document.querySelector('.texto53');
    if (textoElemento53) {
      textoElemento53.textContent = "";
      textoElemento53.style.marginTop = "40px";
    }
  });
}

const imagem22 = document.getElementById('img22');

if (imagem22) {
  imagem22.addEventListener('mouseenter', function () {
    imagem22.style.transform = 'scale(1.2)'; 
    imagem22.src = 'img/r4.webp';

    const minhaDiv = document.getElementById('borda22');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto44');
    if (textoElemento) {
      textoElemento.textContent = "Vichy Minéral Sérum Hidratante";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento54 = document.querySelector('.texto54');
    if (textoElemento54) {
      textoElemento54.textContent = "preço:  170,01R$";
      textoElemento54.style.marginTop = "40px";
    }
  });

  imagem22.addEventListener('mouseleave', function () {
    imagem22.style.transform = 'scale(1)'; 
    imagem22.src = 'img/r3.webp';

    const minhaDiv = document.getElementById('borda22');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto44');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento54 = document.querySelector('.texto54');
    if (textoElemento54) {
      textoElemento54.textContent = "";
      textoElemento54.style.marginTop = "40px";
    }
  });
}
const imagem23 = document.getElementById('img23');

if (imagem23) {
  imagem23.addEventListener('mouseenter', function () {
    imagem23.style.transform = 'scale(1.2)'; 
    imagem23.src = 'img/r6.jpg';

    const minhaDiv = document.getElementById('borda23');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto45');
    if (textoElemento) {
      textoElemento.textContent = "Sérum Facial ";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento55 = document.querySelector('.texto55');
    if (textoElemento55) {
      textoElemento55.textContent = "preço: 68,00R$";
      textoElemento55.style.marginTop = "40px";
    }
  });

  imagem23.addEventListener('mouseleave', function () {
    imagem23.style.transform = 'scale(1)'; 
    imagem23.src = 'img/r5.jpg';

    const minhaDiv = document.getElementById('borda23');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto45');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento55= document.querySelector('.texto55');
    if (textoElemento55) {
      textoElemento55.textContent = "";
      textoElemento55.style.marginTop = "40px";
    }
  });
}

const imagem24 = document.getElementById('img24');

if (imagem24) {
  imagem24.addEventListener('mouseenter', function () {
    imagem24.style.transform = 'scale(1.2)'; 
    imagem24.src = 'img/r8.webp';

    const minhaDiv = document.getElementById('borda24');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto46');
    if (textoElemento) {
      textoElemento.textContent = "NIVEA Creme Facial 100g";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento56 = document.querySelector('.texto56');
    if (textoElemento56) {
      textoElemento56.textContent = "preço: 28,79R$";
      textoElemento56.style.marginTop = "40px";
    }
  });

  imagem24.addEventListener('mouseleave', function () {
    imagem24.style.transform = 'scale(1)'; 
    imagem24.src = 'img/r7.jpg';

    const minhaDiv = document.getElementById('borda24');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto46');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento56= document.querySelector('.texto56');
    if (textoElemento56) {
      textoElemento56.textContent = "";
      textoElemento56.style.marginTop = "40px";
    }
  });
}
const imagem25 = document.getElementById('img25');

if (imagem25) {
  imagem25.addEventListener('mouseenter', function () {
    imagem25.style.transform = 'scale(1.2)'; 
    imagem25.src = 'img/r10.jpg';

    const minhaDiv = document.getElementById('borda25');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto47');
    if (textoElemento) {
      textoElemento.textContent = "Creme Facial Retinol";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento57 = document.querySelector('.texto57');
    if (textoElemento57) {
      textoElemento57.textContent = "preço: 78,04R$";
      textoElemento57.style.marginTop = "40px";
    }
  });

  imagem25.addEventListener('mouseleave', function () {
    imagem25.style.transform = 'scale(1)'; 
    imagem25.src = 'img/r9.jpg';

    const minhaDiv = document.getElementById('borda25');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto47');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento57= document.querySelector('.texto57');
    if (textoElemento57) {
      textoElemento57.textContent = "";
      textoElemento57.style.marginTop = "40px";
    }
  });
}

const imagem26 = document.getElementById('img26');

if (imagem26) {
  imagem26.addEventListener('mouseenter', function () {
    imagem26.style.transform = 'scale(1.2)'; 
    imagem26.src = 'img/r12.jpg';

    const minhaDiv = document.getElementById('borda26');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto48');
    if (textoElemento) {
      textoElemento.textContent = "Hidratante Facial Face Care";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento58 = document.querySelector('.texto58');
    if (textoElemento58) {
      textoElemento58.textContent = "preço: 34,59R$";
      textoElemento58.style.marginTop = "40px";
    }
  });

  imagem26.addEventListener('mouseleave', function () {
    imagem26.style.transform = 'scale(1)'; 
    imagem26.src = 'img/r11.webp';

    const minhaDiv = document.getElementById('borda26');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto48');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento58 = document.querySelector('.texto58');
    if (textoElemento58) {
      textoElemento58.textContent = "";
      textoElemento58.style.marginTop = "40px";
    }
  });
}
const imagem27 = document.getElementById('img27');

if (imagem27) {
  imagem27.addEventListener('mouseenter', function () {
    imagem27.style.transform = 'scale(1.2)'; 
    imagem27.src = 'img/r14.webp';

    const minhaDiv = document.getElementById('borda27');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto49');
    if (textoElemento) {
      textoElemento.textContent = "Creme Antipoluição";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento59 = document.querySelector('.texto59');
    if (textoElemento59) {
      textoElemento59.textContent = "preço: 49,18R$";
      textoElemento59.style.marginTop = "40px";
    }
  });

  imagem27.addEventListener('mouseleave', function () {
    imagem27.style.transform = 'scale(1)'; 
    imagem27.src = 'img/r13.jpg';

    const minhaDiv = document.getElementById('borda27');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto49');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento59= document.querySelector('.texto59');
    if (textoElemento59) {
      textoElemento59.textContent = "";
      textoElemento59.style.marginTop = "40px";
    }
  });
}

const imagem28 = document.getElementById('img28');

if (imagem28) {
  imagem28.addEventListener('mouseenter', function () {
    imagem28.style.transform = 'scale(1.2)'; 
    imagem28.src = 'img/r15.webp';

    const minhaDiv = document.getElementById('borda28');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto50');
    if (textoElemento) {
      textoElemento.textContent = "Água Micelar L'Oréal Paris";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento60 = document.querySelector('.texto60');
    if (textoElemento60) {
      textoElemento60.textContent = "preço: 80,90R$";
      textoElemento60.style.marginTop = "40px";
    }
  });

  imagem28.addEventListener('mouseleave', function () {
    imagem28.style.transform = 'scale(1)'; 
    imagem28.src = 'img/r16.jpg';

    const minhaDiv = document.getElementById('borda28');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto50');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento60= document.querySelector('.texto60');
    if (textoElemento60) {
      textoElemento60.textContent = "";
      textoElemento60.style.marginTop = "40px";
    }
  });
}
    
}
// ------------------------------------------cabelo
if (pagina1=== 'pagina-cabelo'){
const imagem31 = document.getElementById('img31');

if (imagem31) {
  imagem31.addEventListener('mouseenter', function () {
    imagem31.style.transform = 'scale(1.2)'; 
    imagem31.src = 'img/ca2.webp';

    const minhaDiv = document.getElementById('borda31');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto61');
    if (textoElemento) {
      textoElemento.textContent = "OX Peptídeos Cabelos Crespos";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento71 = document.querySelector('.texto71');
    if (textoElemento71) {
      textoElemento71.textContent = "preço: 79,99R$";
      textoElemento71.style.marginTop = "40px";
    }
  });

  imagem31.addEventListener('mouseleave', function () {
    imagem31.style.transform = 'scale(1)'; 
    imagem31.src = 'img/ca1.webp';

    const minhaDiv = document.getElementById('borda31');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto61');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento71 = document.querySelector('.texto71');
    if (textoElemento71) {
      textoElemento71.textContent = "";
      textoElemento71.style.marginTop = "40px";
    }
  });
}

const imagem32 = document.getElementById('img32');

if (imagem32) {
  imagem32.addEventListener('mouseenter', function () {
    imagem32.style.transform = 'scale(1.2)'; 
    imagem32.src = 'img/ca4.webp';

    const minhaDiv = document.getElementById('borda32');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto62');
    if (textoElemento) {
      textoElemento.textContent = "Kit Shampoo + Leave-in Cachos";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento72 = document.querySelector('.texto72');
    if (textoElemento72) {
      textoElemento72.textContent = "preço:  89,99R$";
      textoElemento72.style.marginTop = "40px";
    }
  });

  imagem32.addEventListener('mouseleave', function () {
    imagem32.style.transform = 'scale(1)'; 
    imagem32.src = 'img/ca3.webp';

    const minhaDiv = document.getElementById('borda32');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto62');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento72 = document.querySelector('.texto72');
    if (textoElemento72) {
      textoElemento72.textContent = "";
      textoElemento72.style.marginTop = "40px";
    }
  });
}
const imagem33 = document.getElementById('img33');

if (imagem33) {
  imagem33.addEventListener('mouseenter', function () {
    imagem33.style.transform = 'scale(1.2)'; 
    imagem33.src = 'img/ca6.jpg';

    const minhaDiv = document.getElementById('borda33');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto63');
    if (textoElemento) {
      textoElemento.textContent = "Máscara Vult Ondulados 500g";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento73 = document.querySelector('.texto73');
    if (textoElemento73) {
      textoElemento73.textContent = "preço: 68,00R$";
      textoElemento73.style.marginTop = "40px";
    }
  });

  imagem33.addEventListener('mouseleave', function () {
    imagem33.style.transform = 'scale(1)'; 
    imagem33.src = 'img/ca5.webp';

    const minhaDiv = document.getElementById('borda33');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto63');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento73= document.querySelector('.texto73');
    if (textoElemento73) {
      textoElemento73.textContent = "";
      textoElemento73.style.marginTop = "40px";
    }
  });
}

const imagem34 = document.getElementById('img34');

if (imagem34) {
  imagem34.addEventListener('mouseenter', function () {
    imagem34.style.transform = 'scale(1.2)'; 
    imagem34.src = 'img/ca8.jpg';

    const minhaDiv = document.getElementById('borda34');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto64');
    if (textoElemento) {
      textoElemento.textContent = "NNatura Tododia ";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento74 = document.querySelector('.texto74');
    if (textoElemento74) {
      textoElemento74.textContent = "preço: 28,79R$";
      textoElemento74.style.marginTop = "40px";
    }
  });

  imagem34.addEventListener('mouseleave', function () {
    imagem34.style.transform = 'scale(1)'; 
    imagem34.src = 'img/ca7.webp';

    const minhaDiv = document.getElementById('borda34');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto64');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento74= document.querySelector('.texto74');
    if (textoElemento74) {
      textoElemento74.textContent = "";
      textoElemento74.style.marginTop = "40px";
    }
  });
}
const imagem35 = document.getElementById('img35');

if (imagem35) {
  imagem35.addEventListener('mouseenter', function () {
    imagem35.style.transform = 'scale(1.2)'; 
    imagem35.src = 'img/ca10.webp';

    const minhaDiv = document.getElementById('borda35');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto65');
    if (textoElemento) {
      textoElemento.textContent = "Kit Siàge Resgate Imediato";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento75 = document.querySelector('.texto75');
    if (textoElemento75) {
      textoElemento75.textContent = "preço: 78,04R$";
      textoElemento75.style.marginTop = "40px";
    }
  });

  imagem35.addEventListener('mouseleave', function () {
    imagem35.style.transform = 'scale(1)'; 
    imagem35.src = 'img/ca9.webp';

    const minhaDiv = document.getElementById('borda35');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto65');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento75= document.querySelector('.texto75');
    if (textoElemento75) {
      textoElemento75.textContent = "";
      textoElemento75.style.marginTop = "40px";
    }
  });
}

const imagem36 = document.getElementById('img36');

if (imagem36) {
  imagem36.addEventListener('mouseenter', function () {
    imagem36.style.transform = 'scale(1.2)'; 
    imagem36.src = 'img/ca12.webp';

    const minhaDiv = document.getElementById('borda36');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto66');
    if (textoElemento) {
      textoElemento.textContent = "Kit Cacho Forte";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento76 = document.querySelector('.texto76');
    if (textoElemento76) {
      textoElemento76.textContent = "preço: 34,59R$";
      textoElemento76.style.marginTop = "40px";
    }
  });

  imagem36.addEventListener('mouseleave', function () {
    imagem36.style.transform = 'scale(1)'; 
    imagem36.src = 'img/ca11.jpg';

    const minhaDiv = document.getElementById('borda36');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto66');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento76 = document.querySelector('.texto76');
    if (textoElemento76) {
      textoElemento76.textContent = "";
      textoElemento76.style.marginTop = "40px";
    }
  });
}
const imagem37 = document.getElementById('img37');

if (imagem37) {
  imagem37.addEventListener('mouseenter', function () {
    imagem37.style.transform = 'scale(1.2)'; 
    imagem37.src = 'img/ca14.webp';

    const minhaDiv = document.getElementById('borda37');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto67');
    if (textoElemento) {
      textoElemento.textContent = "Kit Shampoo e Condicionador";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento77= document.querySelector('.texto77');
    if (textoElemento77) {
      textoElemento77.textContent = "preço: 49,18R$";
      textoElemento77.style.marginTop = "40px";
    }
  });

  imagem37.addEventListener('mouseleave', function () {
    imagem37.style.transform = 'scale(1)'; 
    imagem37.src = 'img/ca13.webp';

    const minhaDiv = document.getElementById('borda37');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto67');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento77= document.querySelector('.texto77');
    if (textoElemento77) {
      textoElemento77.textContent = "";
      textoElemento77.style.marginTop = "40px";
    }
  });
}

const imagem38 = document.getElementById('img38');

if (imagem38) {
  imagem38.addEventListener('mouseenter', function () {
    imagem38.style.transform = 'scale(1.2)'; 
    imagem38.src = 'img/ca16.jpg';

    const minhaDiv = document.getElementById('borda38');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto68');
    if (textoElemento) {
      textoElemento.textContent = "Kit Especial Cachos Definidos";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento78 = document.querySelector('.texto78');
    if (textoElemento78) {
      textoElemento78.textContent = "preço: 80,90R$";
      textoElemento78.style.marginTop = "40px";
    }
  });

  imagem38.addEventListener('mouseleave', function () {
    imagem38.style.transform = 'scale(1)'; 
    imagem38.src = 'img/ca15.webp';

    const minhaDiv = document.getElementById('borda38');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto68');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento78= document.querySelector('.texto78');
    if (textoElemento78) {
      textoElemento78.textContent = "";
      textoElemento78.style.marginTop = "40px";
    }
  });
}
    
}
// ----------------------------------galeria
if (pagina1=== 'pagina-galeria'){
const imagem41 = document.getElementById('img41');

if (imagem41) {
  imagem41.addEventListener('mouseenter', function () {
    imagem41.style.transform = 'scale(1.2)'; 
    imagem41.src = 'img/ma2.webp';

    const minhaDiv = document.getElementById('borda41');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto81');
    if (textoElemento) {
      textoElemento.textContent = "Pó Iluminador";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento91 = document.querySelector('.texto91');
    if (textoElemento91) {
      textoElemento91.textContent = "preço: 49,99R$";
      textoElemento91.style.marginTop = "40px";
    }
  });

  imagem41.addEventListener('mouseleave', function () {
    imagem41.style.transform = 'scale(1)'; 
    imagem41.src = 'img/ma1.webp';

    const minhaDiv = document.getElementById('borda41');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto81');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento91 = document.querySelector('.texto91');
    if (textoElemento91) {
      textoElemento91.textContent = "";
      textoElemento91.style.marginTop = "40px";
    }
  });
}

const imagem42 = document.getElementById('img42');

if (imagem42) {
  imagem42.addEventListener('mouseenter', function () {
    imagem42.style.transform = 'scale(1.2)'; 
    imagem42.src = 'img/per5.jpg';

    const minhaDiv = document.getElementById('borda42');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto82');
    if (textoElemento) {
      textoElemento.textContent = "Perfume Attracione Men";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento92 = document.querySelector('.texto92');
    if (textoElemento92) {
      textoElemento92.textContent = "preço: 143,90R$";
      textoElemento92.style.marginTop = "40px";
    }
  });

  imagem42.addEventListener('mouseleave', function () {
    imagem42.style.transform = 'scale(1)'; 
    imagem42.src = 'img/per4.jpg';

    const minhaDiv = document.getElementById('borda42');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto82');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento92 = document.querySelector('.texto92');
    if (textoElemento92) {
      textoElemento92.textContent = "";
      textoElemento92.style.marginTop = "40px";
    }
  });
}
const imagem43 = document.getElementById('img43');

if (imagem43) {
  imagem43.addEventListener('mouseenter', function () {
    imagem43.style.transform = 'scale(1.2)'; 
    imagem43.src = 'img/r6.jpg';

    const minhaDiv = document.getElementById('borda43');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto83');
    if (textoElemento) {
      textoElemento.textContent = "Sérum Facial";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento93 = document.querySelector('.texto93');
    if (textoElemento93) {
      textoElemento93.textContent = "preço: 68,00R$";
      textoElemento93.style.marginTop = "40px";
    }
  });

  imagem43.addEventListener('mouseleave', function () {
    imagem43.style.transform = 'scale(1)'; 
    imagem43.src = 'img/r7.jpg';

    const minhaDiv = document.getElementById('borda43');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto83');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento93= document.querySelector('.texto93');
    if (textoElemento93) {
      textoElemento93.textContent = "";
      textoElemento93.style.marginTop = "40px";
    }
  });
}

const imagem44 = document.getElementById('img44');

if (imagem44) {
  imagem44.addEventListener('mouseenter', function () {
    imagem44.style.transform = 'scale(1.2)'; 
    imagem44.src = 'img/per12.jpg';

    const minhaDiv = document.getElementById('borda44');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto84');
    if (textoElemento) {
      textoElemento.textContent = "Chanel Coco ";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento94 = document.querySelector('.texto94');
    if (textoElemento94) {
      textoElemento94.textContent = "preço: 327,98R$";
      textoElemento94.style.marginTop = "40px";
    }
  });

  imagem44.addEventListener('mouseleave', function () {
    imagem44.style.transform = 'scale(1)'; 
    imagem44.src = 'img/per11.webp';

    const minhaDiv = document.getElementById('borda44');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto84');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento94= document.querySelector('.texto94');
    if (textoElemento94) {
      textoElemento94.textContent = "";
      textoElemento94.style.marginTop = "40px";
    }
  });
}
const imagem45 = document.getElementById('img45');

if (imagem45) {
  imagem45.addEventListener('mouseenter', function () {
    imagem45.style.transform = 'scale(1.2)'; 
    imagem45.src = 'img/per8.webp';

    const minhaDiv = document.getElementById('borda45');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto85');
    if (textoElemento) {
      textoElemento.textContent = "Eudora Impression 100ml";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento95 = document.querySelector('.texto95');
    if (textoElemento95) {
      textoElemento95.textContent = "preço: 165,00R$";
      textoElemento95.style.marginTop = "40px";
    }
  });

  imagem45.addEventListener('mouseleave', function () {
    imagem45.style.transform = 'scale(1)'; 
    imagem45.src = 'img/per7.webp';

    const minhaDiv = document.getElementById('borda45');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto85');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento95= document.querySelector('.texto95');
    if (textoElemento95) {
      textoElemento95.textContent = "";
      textoElemento95.style.marginTop = "40px";
    }
  });
}

const imagem46 = document.getElementById('img46');

if (imagem46) {
  imagem46.addEventListener('mouseenter', function () {
    imagem46.style.transform = 'scale(1.2)'; 
    imagem46.src = 'img/ca12.webp';

    const minhaDiv = document.getElementById('borda46');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto86');
    if (textoElemento) {
      textoElemento.textContent = "Kit Cacho Forte";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento96 = document.querySelector('.texto96');
    if (textoElemento96) {
      textoElemento96.textContent = "preço: 34,59R$";
      textoElemento96.style.marginTop = "40px";
    }
  });

  imagem46.addEventListener('mouseleave', function () {
    imagem46.style.transform = 'scale(1)'; 
    imagem46.src = 'img/ca11.jpg';

    const minhaDiv = document.getElementById('borda46');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto86');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento96 = document.querySelector('.texto96');
    if (textoElemento96) {
      textoElemento96.textContent = "";
      textoElemento96.style.marginTop = "40px";
    }
  });
}
const imagem47 = document.getElementById('img47');

if (imagem47) {
  imagem47.addEventListener('mouseenter', function () {
    imagem47.style.transform = 'scale(1.2)'; 
    imagem47.src = 'img/per14.jpg';

    const minhaDiv = document.getElementById('borda47');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto87');
    if (textoElemento) {
      textoElemento.textContent = "Perfume Lattafa Asad 100 Ml";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento97= document.querySelector('.texto97');
    if (textoElemento97) {
      textoElemento97.textContent = "preço: 146,00R$";
      textoElemento97.style.marginTop = "40px";
    }
  });

  imagem47.addEventListener('mouseleave', function () {
    imagem47.style.transform = 'scale(1)'; 
    imagem47.src = 'img/per13.jpg';

    const minhaDiv = document.getElementById('borda47');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto87');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento97= document.querySelector('.texto97');
    if (textoElemento97) {
      textoElemento97.textContent = "";
      textoElemento97.style.marginTop = "40px";
    }
  });
}

const imagem48 = document.getElementById('img48');

if (imagem48) {
  imagem48.addEventListener('mouseenter', function () {
    imagem48.style.transform = 'scale(1.2)'; 
    imagem48.src = 'img/r12.jpg';

    const minhaDiv = document.getElementById('borda48');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1.2)';
      minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
    }

    const textoElemento = document.querySelector('.texto88');
    if (textoElemento) {
      textoElemento.textContent = "Hidratante Facial Face Care";
      textoElemento.style.marginTop = "20px";
    }

    const textoElemento98 = document.querySelector('.texto98');
    if (textoElemento98) {
      textoElemento98.textContent = "preço: 34,59R$";
      textoElemento98.style.marginTop = "40px";
    }
  });

  imagem48.addEventListener('mouseleave', function () {
    imagem48.style.transform = 'scale(1)'; 
    imagem48.src = 'img/r11.webp';

    const minhaDiv = document.getElementById('borda48');
    if (minhaDiv) {
      minhaDiv.style.transform = 'scale(1)';
      minhaDiv.style.background = 'none';
    }

    const textoElemento = document.querySelector('.texto88');
    if (textoElemento) textoElemento.textContent = "";

    const textoElemento98= document.querySelector('.texto98');
    if (textoElemento98) {
      textoElemento98.textContent = "";
      textoElemento98.style.marginTop = "40px";
    
    }
  });

  const imagem55 = document.getElementById('img55');

  if (imagem55) {
    imagem55.addEventListener('mouseenter', function () {
      imagem55.style.transform = 'scale(1.2)';
      imagem55.src = 'img/ma14.webp';

      const minhaDiv = document.getElementById('borda55');
      if (minhaDiv) {
        minhaDiv.style.transform = 'scale(1.2)';
        minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
      }

      const textoElemento = document.querySelector('.texto100');
      if (textoElemento) {
        textoElemento.textContent = "Batom Liquido Creamy Matte";
        textoElemento.style.marginTop = "20px";
      }

      const textoElemento104 = document.querySelector('.texto104');
      if (textoElemento104) {
        textoElemento104.textContent = "preço: 69,20R$";
        textoElemento104.style.marginTop = "40px";
      }
    });
  }
    imagem55.addEventListener('mouseleave', function () {
      imagem55.style.transform = 'scale(1)';
      imagem55.src = 'img/ma13.JPG';

      const minhaDiv = document.getElementById('borda55');
      if (minhaDiv) {
        minhaDiv.style.transform = 'scale(1)';
        minhaDiv.style.background = 'none';
      }

      const textoElemento = document.querySelector('.texto100');
      if (textoElemento) textoElemento.textContent = "";

      const textoElemento104 = document.querySelector('.texto104');
      if (textoElemento104) {
        textoElemento104.textContent = "";
        textoElemento104.style.marginTop = "40px";
      }
    });
  }

  const imagem56 = document.getElementById('img56');

  if (imagem56) {
    imagem56.addEventListener('mouseenter', function () {
      imagem56.style.transform = 'scale(1.2)';
      imagem56.src = 'img/per3.webp';

      const minhaDiv = document.getElementById('borda56');
      if (minhaDiv) {
        minhaDiv.style.transform = 'scale(1.2)';
        minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
      }

      const textoElemento = document.querySelector('.texto101');
      if (textoElemento) {
        textoElemento.textContent = "Perfume Granado Expedição 75ml";
        textoElemento.style.marginTop = "20px";
      }

      const textoElemento105 = document.querySelector('.texto105');
      if (textoElemento105) {
        textoElemento105.textContent = "preço:  325,00R$";
        textoElemento105.style.marginTop = "40px";
      }
    });

    imagem56.addEventListener('mouseleave', function () {
      imagem56.style.transform = 'scale(1)';
      imagem56.src = 'img/per2.webp';

      const minhaDiv = document.getElementById('borda56');
      if (minhaDiv) {
        minhaDiv.style.transform = 'scale(1)';
        minhaDiv.style.background = 'none';
      }

      const textoElemento = document.querySelector('.texto101');
      if (textoElemento) textoElemento.textContent = "";

      const textoElemento105 = document.querySelector('.texto105');
      if (textoElemento105) {
        textoElemento105.textContent = "";
        textoElemento105.style.marginTop = "40px";
      }
    });
  }

  const imagem57 = document.getElementById('img57');

  if (imagem57) {
    imagem57.addEventListener('mouseenter', function () {
      imagem57.style.transform = 'scale(1.2)';
      imagem57.src = 'img/ma10.webp';

      const minhaDiv = document.getElementById('borda57');
      if (minhaDiv) {
        minhaDiv.style.transform = 'scale(1.2)';
        minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
      }

      const textoElemento = document.querySelector('.texto102');
      if (textoElemento) {
        textoElemento.textContent = "Base e Corretivo Matte ";
        textoElemento.style.marginTop = "20px";
      }

      const textoElemento106 = document.querySelector('.texto106');
      if (textoElemento106) {
        textoElemento106.textContent = "preço: 59,90R$";
        textoElemento106.style.marginTop = "40px";
      }
    });

    imagem57.addEventListener('mouseleave', function () {
      imagem57.style.transform = 'scale(1)';
      imagem57.src = 'img/ma9.webp';

      const minhaDiv = document.getElementById('borda57');
      if (minhaDiv) {
        minhaDiv.style.transform = 'scale(1)';
        minhaDiv.style.background = 'none';
      }

      const textoElemento = document.querySelector('.texto102');
      if (textoElemento) textoElemento.textContent = "";

      const textoElemento106 = document.querySelector('.texto106');
      if (textoElemento106) {
        textoElemento106.textContent = "";
        textoElemento106.style.marginTop = "40px";
      }
    });
  }

  const imagem58 = document.getElementById('img58');

  if (imagem58) {
    imagem58.addEventListener('mouseenter', function () {
      imagem58.style.transform = 'scale(1.2)';
      imagem58.src = 'img/per17.jpg';

      const minhaDiv = document.getElementById('borda58');
      if (minhaDiv) {
        minhaDiv.style.transform = 'scale(1.2)';
        minhaDiv.style.background = 'rgba(200, 200, 200, 0.9)';
      }

      const textoElemento = document.querySelector('.texto103');
      if (textoElemento) {
        textoElemento.textContent = "Golden Gardênia 75ml";
        textoElemento.style.marginTop = "20px";
      }

      const textoElemento107 = document.querySelector('.texto107');
      if (textoElemento107) {
        textoElemento107.textContent = "preço: 229,90R$";
        textoElemento107.style.marginTop = "40px";
      }
    });

    imagem58.addEventListener('mouseleave', function () {
      imagem58.style.transform = 'scale(1)';
      imagem58.src = 'img/per16.jpg';

      const minhaDiv = document.getElementById('borda58');
      if (minhaDiv) {
        minhaDiv.style.transform = 'scale(1)';
        minhaDiv.style.background = 'none';
      }

      const textoElemento = document.querySelector('.texto103');
      if (textoElemento) textoElemento.textContent = "";

      const textoElemento107 = document.querySelector('.texto107');
      if (textoElemento107) {
        textoElemento107.textContent = "";
        textoElemento107.style.marginTop = "40px";
      }
    });
  }
}


